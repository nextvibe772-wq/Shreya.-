
package com.shreya.assistant.core.di
import android.content.Context
import com.shreya.assistant.ai.router.ModelRouter
import com.shreya.assistant.ai.providers.*
import com.shreya.assistant.database.AppDatabase
import com.shreya.assistant.memory.MemoryManager
import com.shreya.assistant.security.SecureKeyStore
import com.shreya.assistant.security.SecurityManager
import com.shreya.assistant.permissions.PermissionManager
import com.shreya.assistant.voice.stt.STTManager
import com.shreya.assistant.voice.tts.TTSManager
import com.shreya.assistant.voice.wakeword.WakeWordManager
import com.shreya.assistant.nlu.CommandUnderstandingManager
import com.shreya.assistant.skills.SkillRouter
import com.shreya.assistant.diagnostics.DiagnosticManager
import com.shreya.assistant.tasks.TaskManager
object ServiceLocator {
    lateinit var appContext: Context
    lateinit var database: AppDatabase
    lateinit var secureKeyStore: SecureKeyStore
    lateinit var securityManager: SecurityManager
    lateinit var permissionManager: PermissionManager
    lateinit var modelRouter: ModelRouter
    lateinit var sttManager: STTManager
    lateinit var ttsManager: TTSManager
    lateinit var wakeWordManager: WakeWordManager
    lateinit var memoryManager: MemoryManager
    lateinit var commandManager: CommandUnderstandingManager
    lateinit var skillRouter: SkillRouter
    lateinit var taskManager: TaskManager
    lateinit var diagnosticManager: DiagnosticManager

    fun init(context: Context) {
        appContext = context.applicationContext
        database = AppDatabase.create(appContext)
        secureKeyStore = SecureKeyStore(appContext)
        securityManager = SecurityManager(secureKeyStore)
        permissionManager = PermissionManager(appContext)
        val providers = mapOf(
            "groq" to GroqProvider(secureKeyStore),
            "openai" to OpenAIProvider(secureKeyStore),
            "gemini" to GeminiProvider(secureKeyStore),
            "claude" to ClaudeProvider(secureKeyStore),
            "custom" to CustomOpenAIProvider(secureKeyStore)
        )
        modelRouter = ModelRouter(providers, database.providerDao())
        sttManager = STTManager(appContext)
        ttsManager = TTSManager(appContext)
        wakeWordManager = WakeWordManager(appContext)
        memoryManager = MemoryManager(database.memoryDao())
        commandManager = CommandUnderstandingManager()
        skillRouter = SkillRouter(appContext, database)
        taskManager = TaskManager(database.taskDao(), appContext)
        diagnosticManager = DiagnosticManager(appContext, modelRouter, sttManager, ttsManager, permissionManager)
    }
}
