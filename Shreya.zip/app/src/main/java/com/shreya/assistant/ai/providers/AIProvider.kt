
package com.shreya.assistant.ai.providers
import kotlinx.coroutines.flow.Flow

data class ChatMessage(val role: String, val content: String)
data class AIRequest(
    val messages: List<ChatMessage>,
    val model: String,
    val stream: Boolean = true,
    val temperature: Float = 0.7f,
    val maxTokens: Int = 2048,
    val systemPrompt: String? = null
)
data class AIResponseChunk(val text: String, val isFinal: Boolean = false, val usage: Usage? = null)
data class Usage(val promptTokens: Int, val completionTokens: Int)
sealed class ProviderResult {
    data class Success(val fullText: String, val latencyMs: Long, val usage: Usage?) : ProviderResult()
    data class Stream(val flow: Flow<AIResponseChunk>) : ProviderResult()
    data class Error(val code: String, val message: String, val recoverable: Boolean) : ProviderResult()
}
interface AIProvider {
    val id: String
    val displayName: String
    suspend fun chat(request: AIRequest): ProviderResult
    suspend fun chatStream(request: AIRequest): Flow<AIResponseChunk>
    suspend fun testConnection(): TestResult
    fun supportedModels(): List<String>
}
data class TestResult(val ok: Boolean, val status: String, val latencyMs: Long)
