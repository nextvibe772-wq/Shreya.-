
package com.shreya.assistant.ai.router
import com.shreya.assistant.ai.providers.*
import com.shreya.assistant.core.IdentityManager
import com.shreya.assistant.database.dao.ProviderDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class ModelRouter(
    private val providers: Map<String, AIProvider>,
    private val providerDao: ProviderDao
) {
    var primaryId: String = "groq"
    var fallbackIds: List<String> = listOf("openai","gemini")
    var fallbackEnabled: Boolean = true

    suspend fun routeWithIdentity(request: AIRequest, userLanguage: String = "hinglish"): Flow<AIResponseChunk> = flow {
        val lastUserMsg = request.messages.lastOrNull()?.content ?: ""
        
        // IDENTITY INTERCEPT - Prafull creator
        if (IdentityManager.isCreatorQuestion(lastUserMsg)) {
            // Check if asking about Prafull details or just creator
            if (IdentityManager.isAboutPrafull(lastUserMsg)) {
                val detailed = IdentityManager.getCreatorDetailedAnswer()
                detailed.split(" ").forEach { word ->
                    emit(AIResponseChunk(word + " ", false))
                    kotlinx.coroutines.delay(25)
                }
            } else {
                val answer = IdentityManager.getCreatorAnswer()
                emit(AIResponseChunk(answer, false))
            }
            emit(AIResponseChunk("", true))
            return@flow
        }

        // Normal routing with identity system prompt
        val systemPromptWithIdentity = IdentityManager.getSystemPrompt(userLanguage)
        val enrichedRequest = request.copy(
            systemPrompt = systemPromptWithIdentity + "\n" + (request.systemPrompt ?: "")
        )
        
        val order = listOf(primaryId) + if (fallbackEnabled) fallbackIds else emptyList()
        var emitted = false
        for (pid in order.distinct()) {
            val provider = providers[pid] ?: continue
            try {
                val stream = provider.chatStream(enrichedRequest.copy(model = providerDao.getById(pid)?.selectedModel ?: enrichedRequest.model))
                stream.collect { 
                    emitted = true
                    emit(it) 
                }
                if (emitted) return@flow
            } catch (e: Exception) {
                continue
            }
        }
        emit(AIResponseChunk("⚠️ Service temporarily unavailable. Please check API configuration.", true))
    }

    // Backward compat
    suspend fun route(request: AIRequest): Flow<AIResponseChunk> = routeWithIdentity(request)

    suspend fun testProvider(id: String): TestResult = providers[id]?.testConnection() ?: TestResult(false,"Unknown provider",0)
    fun listProviders() = providers.values.toList()
}
