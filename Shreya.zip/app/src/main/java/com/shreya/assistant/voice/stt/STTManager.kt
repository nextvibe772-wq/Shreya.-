
package com.shreya.assistant.voice.stt
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class STTManager(private val context: Context) {
    private val _state = MutableStateFlow(STTState.IDLE)
    val state: StateFlow<STTState> = _state
    private var recognizer: SpeechRecognizer? = null

    enum class STTState { IDLE, LISTENING, PROCESSING, ERROR }

    fun startListening(language: String = "en-IN", onResult: (String, Boolean) -> Unit) {
        _state.value = STTState.LISTENING
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(p: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { _state.value = STTState.PROCESSING }
                override fun onError(e: Int) { _state.value = STTState.ERROR; onResult("", false) }
                override fun onResults(r: android.os.Bundle?) {
                    val list = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    _state.value = STTState.IDLE
                    onResult(list?.firstOrNull() ?: "", false)
                }
                override fun onPartialResults(r: android.os.Bundle?) {
                    val list = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    onResult(list?.firstOrNull() ?: "", true)
                }
                override fun onEvent(t: Int, p: android.os.Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            }
            startListening(intent)
        }
    }
    fun stop() { recognizer?.stopListening(); _state.value = STTState.IDLE }
    fun destroy() { recognizer?.destroy(); recognizer = null }
}
