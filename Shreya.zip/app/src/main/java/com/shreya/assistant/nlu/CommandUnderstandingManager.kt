
package com.shreya.assistant.nlu
enum class CommandType { CHAT, SEARCH, OPEN_APP, FILE, MEDIA, PHONE, BLUETOOTH, PC, SMART_HOME, TASK, MEMORY, SETTINGS, DEVELOPER, UNKNOWN }
data class ParsedCommand(val type: CommandType, val raw: String, val entities: Map<String,String> = emptyMap(), val confidence: Float)
class CommandUnderstandingManager {
    fun parse(input: String): ParsedCommand {
        val lower = input.lowercase()
        return when {
            lower.startsWith("open ") || lower.startsWith("launch ") -> ParsedCommand(CommandType.OPEN_APP, input, mapOf("app" to input.substringAfter("open ").trim()))
            lower.contains("remember") || lower.contains("याद रखो") -> ParsedCommand(CommandType.MEMORY, input)
            lower.contains("search") || lower.contains("खोजो") -> ParsedCommand(CommandType.SEARCH, input)
            lower.contains("turn on") || lower.contains("light") || lower.contains("लाइट") -> ParsedCommand(CommandType.SMART_HOME, input)
            lower.contains("bluetooth") -> ParsedCommand(CommandType.BLUETOOTH, input)
            lower.contains("task") || lower.contains("remind") || lower.contains("याद दिला") -> ParsedCommand(CommandType.TASK, input)
            lower.contains("file") -> ParsedCommand(CommandType.FILE, input)
            lower.contains("play") || lower.contains("pause") || lower.contains("music") -> ParsedCommand(CommandType.MEDIA, input)
            else -> ParsedCommand(CommandType.CHAT, input, confidence = 0.8f)
        }
    }
}
