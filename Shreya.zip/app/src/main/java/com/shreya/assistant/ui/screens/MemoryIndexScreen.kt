
package com.shreya.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.shreya.assistant.core.di.ServiceLocator
import com.shreya.assistant.database.entities.MemoryEntity
import kotlinx.coroutines.launch

@Composable
fun MemoryIndexScreen(nav: NavController) {
    val scope = rememberCoroutineScope()
    val memoryDao = ServiceLocator.database.memoryDao()
    var memories by remember { mutableStateOf(listOf<MemoryEntity>()) }
    var showAddDialog by remember { mutableStateOf(false) }
    var titleInput by remember { mutableStateOf("") }
    var contentInput by remember { mutableStateOf("") }
    
    LaunchedEffect(Unit) {
        memoryDao.all().collect { memories = it }
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF0A0A0F)).padding(16.dp)
    ) {
        // Header like screenshot
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Column {
                Text("Memory index", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Stored locally on this device", color = Color(0xFF9CA3AF), fontSize = 14.sp)
                Spacer(Modifier.height(16.dp))
                Text("${memories.size.toString().padStart(2,'0')}", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("LOCAL ENTRIES", color = Color(0xFF9CA3AF), fontSize = 12.sp, letterSpacing = 1.sp)
            }
            if (!showAddDialog) {
                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF6B2C)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("+  Add memory", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = { showAddDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF6B2C)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("X  Close", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // New memory card - like second photo
        if (showAddDialog) {
            Spacer(Modifier.height(16.dp))
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2A))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("New memory", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        placeholder = { Text("Title, e.g. Preferred language", color = Color.Gray) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF2A2A3A),
                            unfocusedContainerColor = Color(0xFF2A2A3A),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = contentInput,
                        onValueChange = { contentInput = it },
                        placeholder = { Text("What should SHREYA remember?", color = Color.Gray) },
                        modifier = Modifier.fillMaxWidth().height(80.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF2A2A3A),
                            unfocusedContainerColor = Color(0xFF2A2A3A),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            if (titleInput.isNotBlank() && contentInput.isNotBlank()) {
                                scope.launch {
                                    ServiceLocator.memoryManager.save(titleInput, contentInput, "user_preference")
                                    titleInput = ""
                                    contentInput = ""
                                    showAddDialog = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF6B2C)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Save locally", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("MEMORY TYPES", color = Color(0xFFFF6B2C), fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Text("Indexed context", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        
        Spacer(Modifier.height(16.dp))

        // Memory list or empty state like photo
        if (memories.isEmpty()) {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2A))
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.size(56.dp).background(Color(0xFF2A1F1A), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🗄️", fontSize = 24.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("No stored memories yet", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Add a preference or fact when you want SHREYA to personalize future sessions. Sensitive information should only be saved with your confirmation.",
                        color = Color(0xFF9CA3AF),
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 8.dp),
                        lineHeight = 18.sp
                    )
                    Spacer(Modifier.height(16.dp))
                    OutlinedButton(
                        onClick = { showAddDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF6B2C))
                    ) {
                        Text("Create first memory", color = Color(0xFFFF6B2C))
                    }
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(memories) { mem ->
                    Card(
                        Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2A))
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(mem.key, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(mem.value, color = Color(0xFF9CA3AF), fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.weight(1f))
        // Bottom nav like screenshot
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF0A0A0F)).padding(top = 12.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("💬", fontSize = 20.sp); Text("Chat", color = Color.Gray, fontSize = 11.sp) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("🎙️", fontSize = 20.sp); Text("Voice", color = Color.Gray, fontSize = 11.sp) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("🧠", fontSize = 20.sp); Text("Memory", color = Color(0xFFFF6B2C), fontSize = 11.sp) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("⚙️", fontSize = 20.sp); Text("Settings", color = Color.Gray, fontSize = 11.sp) }
        }
    }
}
