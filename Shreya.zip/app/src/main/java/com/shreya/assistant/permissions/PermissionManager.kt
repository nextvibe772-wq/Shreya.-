
package com.shreya.assistant.permissions
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
class PermissionManager(private val ctx: Context) {
    data class PermStatus(val permission: String, val granted: Boolean, val reason: String)
    fun check(perm: String): PermStatus {
        val granted = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
        return PermStatus(perm, granted, when(perm) {
            android.Manifest.permission.RECORD_AUDIO -> "Required for voice conversation"
            android.Manifest.permission.BLUETOOTH_CONNECT -> "Required for Bluetooth devices"
            else -> "Required for feature"
        })
    }
    fun allNeeded() = listOf(
        android.Manifest.permission.RECORD_AUDIO,
        android.Manifest.permission.BLUETOOTH_CONNECT,
        android.Manifest.permission.BLUETOOTH_SCAN,
        android.Manifest.permission.POST_NOTIFICATIONS
    ).map { check(it) }
}
