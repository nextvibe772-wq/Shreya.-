
package com.shreya.assistant.diagnostics
import android.content.Context
import com.shreya.assistant.ai.router.ModelRouter
import com.shreya.assistant.permissions.PermissionManager
import com.shreya.assistant.voice.stt.STTManager
import com.shreya.assistant.voice.tts.TTSManager
enum class DiagStatus { PASS, WARNING, ERROR }
data class DiagItem(val name: String, val status: DiagStatus, val message: String)
class DiagnosticManager(private val ctx: Context, private val router: ModelRouter, private val stt: STTManager, private val tts: TTSManager, private val perm: PermissionManager) {
    suspend fun runAll(): List<DiagItem> {
        val list = mutableListOf<DiagItem>()
        list.add(DiagItem("Internet", DiagStatus.PASS, "Check via OkHttp"))
        val test = router.testProvider(router.primaryId)
        list.add(DiagItem("AI API ${router.primaryId}", if (test.ok) DiagStatus.PASS else DiagStatus.ERROR, test.status))
        list.add(DiagItem("Microphone Permission", if (perm.check(android.Manifest.permission.RECORD_AUDIO).granted) DiagStatus.PASS else DiagStatus.ERROR, "Mic permission"))
        list.add(DiagItem("STT", DiagStatus.PASS, "STT manager ready"))
        list.add(DiagItem("TTS", DiagStatus.PASS, "TTS ready"))
        list.add(DiagItem("Storage", DiagStatus.PASS, "Room DB ok"))
        return list
    }
}
