
package com.shreya.assistant.voice.tts
import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.*

class TTSManager(context: Context): TextToSpeech.OnInitListener {
    private var tts: TextToSpeech = TextToSpeech(context, this)
    private val _state = MutableStateFlow(TTSState.IDLE)
    val state: StateFlow<TTSState> = _state
    var speechRate = 1.0f
    var autoSpeak = true

    enum class TTSState { IDLE, SPEAKING, PAUSED, ERROR }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("en","IN")
            tts.setOnUtteranceProgressListener(object: UtteranceProgressListener() {
                override fun onStart(id: String?) { _state.value = TTSState.SPEAKING }
                override fun onDone(id: String?) { _state.value = TTSState.IDLE }
                @Deprecated("Deprecated") override fun onError(id: String?) { _state.value = TTSState.ERROR }
                override fun onError(id: String?, code: Int) { _state.value = TTSState.ERROR }
            })
        }
    }

    fun speakClean(text: String) {
        if (!autoSpeak) return
        val cleaned = cleanForSpeech(text)
        val chunks = splitIntoSentences(cleaned)
        tts.setSpeechRate(speechRate)
        chunks.forEachIndexed { i, s ->
            tts.speak(s, if (i==0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "shreya_$i")
        }
    }
    private fun cleanForSpeech(input: String): String {
        var t = input
        t = t.replace(Regex("```[\\s\\S]*?```"), " code block ")
        t = t.replace(Regex("[#*_`>]+"), "")
        t = t.replace(Regex("https?://\\S+"), " link ")
        return t
    }
    private fun splitIntoSentences(text: String): List<String> {
        return text.split(Regex("(?<=[.!?।])\\s+")).filter { it.isNotBlank() }.take(20)
    }
    fun stop() { tts.stop(); _state.value = TTSState.IDLE }
    fun setLanguage(locale: Locale) { tts.language = locale }
    fun shutdown() { tts.shutdown() }
}
