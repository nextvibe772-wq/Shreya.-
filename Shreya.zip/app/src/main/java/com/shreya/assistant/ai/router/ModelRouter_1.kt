
package com.shreya.assistant.ai.router
import com.shreya.assistant.ai.providers.*
import com.shreya.assistant.database.dao.ProviderDao
import com.shreya.assistant.database.entities.ProviderConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import timber.log.Timber

class ModelRouter(
    private val providers: Map<String, AIProvider>,
    private val providerDao: ProviderDao
) {
    var primaryId: String = "groq"
    var fallbackIds: List<String> = listOf("openai","gemini")
    var fallbackEnabled: Boolean = true

    suspend fun route(request: AIRequest): Flow<AIResponseChunk> = flow {
        val tried = mutableListOf<String>()
        val order = listOf(primaryId) + if (fallbackEnabled) fallbackIds else emptyList()
        var lastError: ProviderResult.Error? = null
        for (pid in order.distinct()) {
            val provider = providers[pid] ?: continue
            tried.add(pid)
            try {
                Timber.d("Routing to $pid")
                val start = System.currentTimeMillis()
                val stream = provider.chatStream(request.copy(model = resolveModel(pid, request.model)))
                stream.collect { chunk ->
                    emit(chunk)
                }
                providerDao.updateLastLatency(pid, System.currentTimeMillis()-start)
                return@flow
            } catch (e: Exception) {
                lastError = ProviderResult.Error("PROVIDER_FAIL", e.message ?: "fail", true)
                Timber.e(e, "Provider $pid failed")
                if (isRateLimit(e)) {
                    // switch to next
                }
                continue
            }
        }
        emit(AIResponseChunk("⚠️ All providers failed (${tried.joinToString()}). Last error: ${lastError?.message}", true))
    }

    private suspend fun resolveModel(providerId: String, requested: String): String {
        val cfg = providerDao.getById(providerId)
        return cfg?.selectedModel ?: requested
    }

    private fun isRateLimit(e: Exception): Boolean = e.message?.contains("429") == true || e.message?.contains("rate") == true

    suspend fun testProvider(id: String): TestResult = providers[id]?.testConnection() ?: TestResult(false,"Unknown provider",0)
    fun listProviders() = providers.values.toList()
}
