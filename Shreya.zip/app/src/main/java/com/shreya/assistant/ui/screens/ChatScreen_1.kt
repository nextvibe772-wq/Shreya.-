
package com.shreya.assistant.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.shreya.assistant.core.di.ServiceLocator
import com.shreya.assistant.ai.providers.ChatMessage
import com.shreya.assistant.ai.providers.AIRequest
import kotlinx.coroutines.launch
import java.util.UUID

enum class VoiceButtonState { IDLE, LISTENING, PROCESSING, SPEAKING, ERROR }

@Composable
fun ChatScreen(nav: NavController) {
    val router = ServiceLocator.modelRouter
    val tts = ServiceLocator.ttsManager
    val stt = ServiceLocator.sttManager
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var streaming by remember { mutableStateOf("") }
    var voiceState by remember { mutableStateOf(VoiceButtonState.IDLE) }
    var bgActive by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B12)).padding(16.dp)) {
        // Header
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("SHREYA", style = MaterialTheme.typography.headlineMedium, color = Color.White)
            Row {
                AssistChip(onClick = { nav.navigate("api") }, label = { Text(router.primaryId) })
                Spacer(Modifier.width(8.dp))
                Badge { Text(if (bgActive) "🟢" else "🔴") }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Model: llama-3.1-70b • Mic: ${voiceState.name}", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
            Text("BG: ${if (bgActive) "Active" else "Off"}", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
        }
        // Messages
        LazyColumn(Modifier.weight(1f)) {
            items(messages) { m ->
                Box(Modifier.fillMaxWidth().padding(4.dp).background(if (m.role=="user") Color(0xFF2A2A3C) else Color(0xFF1A1A2A), RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Text(m.content, color = Color.White)
                }
            }
            if (streaming.isNotEmpty()) {
                item { Box(Modifier.fillMaxWidth().padding(4.dp).background(Color(0xFF1A1A2A), RoundedCornerShape(12.dp)).padding(12.dp)) { Text(streaming, color = Color.White) } }
            }
        }
        // Input row
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Ask Shreya... Hindi/English/Hinglish") })
            Spacer(Modifier.width(8.dp))
            FilledTonalButton(onClick = {
                if (input.isBlank()) return@FilledTonalButton
                val userMsg = ChatMessage("user", input)
                messages = messages + userMsg
                val prompt = input; input = ""; streaming = ""
                scope.launch {
                    voiceState = VoiceButtonState.PROCESSING
                    router.route(AIRequest(messages, model = "llama-3.1-70b-versatile", systemPrompt = "You are SHREYA, a helpful personal AI assistant. Support Hindi, English, Hinglish.")).collect { chunk ->
                        streaming += chunk.text
                        if (chunk.isFinal) {
                            messages = messages + ChatMessage("assistant", streaming)
                            tts.speakClean(streaming)
                            voiceState = VoiceButtonState.SPEAKING
                            streaming = ""
                        }
                    }
                    voiceState = VoiceButtonState.IDLE
                }
            }) { Text("Send") }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = {
                voiceState = VoiceButtonState.LISTENING
                stt.startListening(if (input.contains("ह")) "hi-IN" else "en-IN") { text, partial ->
                    if (!partial && text.isNotBlank()) {
                        input = text
                        voiceState = VoiceButtonState.IDLE
                    }
                }
            }) { Text(if (voiceState==VoiceButtonState.LISTENING) "🎙️ Listening..." else "🎙️ Voice") }
            OutlinedButton(onClick = { tts.stop(); voiceState = VoiceButtonState.IDLE }) { Text("⏹ Stop") }
            OutlinedButton(onClick = { nav.navigate("settings") }) { Text("⚙️ Settings") }
        }
    }
}
@Composable fun ApiSettingsScreen(nav: NavController) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("API Manager: Groq, OpenAI, Gemini, Claude, Custom - Secure Keystore storage, TEST CONNECTION, SAVE, ACTIVATE implemented in ProviderDao", color = Color.White) } }
@Composable fun SettingsScreen(nav: NavController) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Settings: GENERAL, AI & MODELS, VOICE, WAKE WORD, BACKGROUND, MEMORY, PERMISSIONS, SKILLS, DEVICES, PC, SMART HOME, PRIVACY, SECURITY, DEVELOPER", color = Color.White) } }
@Composable fun MemoryScreen(nav: NavController) { Text("Memory: View/Search/Delete/Clear") }
@Composable fun DevicesScreen(nav: NavController) { Text("Devices: BT/BLE, ESP32/RPi via HTTP/MQTT") }
@Composable fun DeveloperConsoleScreen(nav: NavController) { Text("Developer Console: provider, latency, STT/TTS/Mic/BG status, skill status, test buttons, masked secrets") }
@Composable fun DiagnosticsScreen(nav: NavController) { Text("Diagnostics: PASS/WARNING/ERROR for Internet, API, Mic, STT/TTS, Permissions, BG, BT, Storage") }
@Composable fun PermissionsScreen(nav: NavController) { Text("Permission Manager: Mic, BT, Notifications, Location, Files - Grant/Open Settings") }
