
package com.shreya.assistant.database.entities
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "conversations")
data class ConversationEntity(@PrimaryKey val id: String, val title: String, val createdAt: Long, val updatedAt: Long, val providerId: String)
@Entity(tableName = "messages")
data class MessageEntity(@PrimaryKey val id: String, val conversationId: String, val role: String, val content: String, val timestamp: Long, val model: String? = null)
@Entity(tableName = "memories")
data class MemoryEntity(@PrimaryKey val id: String, val key: String, val value: String, val type: String, val createdAt: Long)
@Entity(tableName = "providers")
data class ProviderConfig(@PrimaryKey val id: String, val displayName: String, val baseUrl: String?, val selectedModel: String?, val isPrimary: Boolean = false, val isEnabled: Boolean = true, val lastLatencyMs: Long = 0)
@Entity(tableName = "tasks")
data class TaskEntity(@PrimaryKey val id: String, val title: String, val description: String?, val dueAt: Long?, val completed: Boolean = false, val createdAt: Long)
@Entity(tableName = "devices")
data class DeviceEntity(@PrimaryKey val id: String, val name: String, val protocol: String, val address: String, val capabilities: String)
@Entity(tableName = "diagnostics")
data class DiagnosticLogEntity(@PrimaryKey val id: String, val timestamp: Long, val level: String, val tag: String, val message: String)
