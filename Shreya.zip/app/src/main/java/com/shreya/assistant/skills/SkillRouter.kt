
package com.shreya.assistant.skills
import android.content.Context
import android.content.Intent
import com.shreya.assistant.database.AppDatabase
import com.shreya.assistant.nlu.CommandType
import com.shreya.assistant.nlu.ParsedCommand

interface Skill {
    val id: String; val name: String; val description: String
    val permissions: List<String>
    fun canHandle(type: CommandType): Boolean
    suspend fun execute(command: ParsedCommand): SkillResult
    fun requiresConfirmation(): Boolean = false
}
data class SkillResult(val success: Boolean, val message: String, val data: Any? = null, val errorCode: String? = null)

class SkillRouter(private val ctx: Context, private val db: AppDatabase) {
    private val skills: List<Skill> = listOf(
        AppSkill(ctx), FileSkill(ctx), MediaSkill(ctx), InternetSkill(), BluetoothSkill(ctx), TaskSkill(db), MemorySkill(db), PCSkill(), SmartHomeSkill(db)
    )
    suspend fun route(cmd: ParsedCommand): SkillResult {
        if (cmd.type == com.shreya.assistant.nlu.CommandType.CHAT) return SkillResult(false, "CHAT", null)
        val skill = skills.firstOrNull { it.canHandle(cmd.type) } ?: return SkillResult(false, "No skill for ${cmd.type}", errorCode="NO_SKILL")
        if (skill.requiresConfirmation()) {
            // confirmation handled by UI layer
        }
        return skill.execute(cmd)
    }
}

// Implementations
class AppSkill(private val ctx: Context): Skill {
    override val id="app"; override val name="App Skill"; override val description="Open apps, settings"
    override val permissions=listOf()
    override fun canHandle(type: CommandType)=type==CommandType.OPEN_APP || type==CommandType.SETTINGS
    override suspend fun execute(command: ParsedCommand): SkillResult {
        val appName = command.entities["app"] ?: command.raw.substringAfter("open ").trim()
        return try {
            val pm = ctx.packageManager
            val launch = pm.getLaunchIntentForPackage(appName) ?: pm.getLaunchIntentForPackage("com.google.android.youtube")
            if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(launch); SkillResult(true, "Opened $appName") }
            else SkillResult(false, "App not found: $appName", errorCode="APP_NOT_FOUND")
        } catch (e: Exception) { SkillResult(false, e.message ?: "Failed", errorCode="APP_ERROR") }
    }
}
class FileSkill(private val ctx: Context): Skill {
    override val id="file"; override val name="File Skill"; override val description="File ops"
    override val permissions=listOf(android.Manifest.permission.READ_MEDIA_IMAGES)
    override fun canHandle(type: CommandType)=type==CommandType.FILE
    override fun requiresConfirmation()=true
    override suspend fun execute(command: ParsedCommand)=SkillResult(true, "File operation: ${command.raw}")
}
class MediaSkill(private val ctx: Context): Skill {
    override val id="media"; override val name="Media Skill"; override val description="Media control"
    override val permissions=listOf()
    override fun canHandle(type: CommandType)=type==CommandType.MEDIA
    override suspend fun execute(command: ParsedCommand)=SkillResult(true, "Media: ${command.raw}")
}
class InternetSkill: Skill {
    override val id="internet"; override val name="Internet Skill"; override val description="Search"
    override val permissions=listOf()
    override fun canHandle(type: CommandType)=type==CommandType.SEARCH
    override suspend fun execute(command: ParsedCommand)=SkillResult(true, "Searching for ${command.raw}", mapOf("query" to command.raw))
}
class BluetoothSkill(private val ctx: Context): Skill {
    override val id="bt"; override val name="Bluetooth"; override val description="BT/BLE"
    override val permissions=listOf(android.Manifest.permission.BLUETOOTH_CONNECT, android.Manifest.permission.BLUETOOTH_SCAN)
    override fun canHandle(type: CommandType)=type==CommandType.BLUETOOTH
    override suspend fun execute(command: ParsedCommand)=SkillResult(true, "Bluetooth: ${command.raw}")
}
class TaskSkill(private val db: AppDatabase): Skill {
    override val id="task"; override val name="Task Skill"; override val description="Tasks"
    override val permissions=listOf()
    override fun canHandle(type: CommandType)=type==CommandType.TASK
    override suspend fun execute(command: ParsedCommand)=SkillResult(true, "Task created: ${command.raw}")
}
class MemorySkill(private val db: AppDatabase): Skill {
    override val id="memory"; override val name="Memory Skill"; override val description="Memory"
    override val permissions=listOf()
    override fun canHandle(type: CommandType)=type==CommandType.MEMORY
    override suspend fun execute(command: ParsedCommand)=SkillResult(true, "Memory saved: ${command.raw}")
}
class PCSkill: Skill {
    override val id="pc"; override val name="PC Companion"; override val description="PC bridge"
    override val permissions=listOf()
    override fun canHandle(type: CommandType)=type==CommandType.PC
    override fun requiresConfirmation()=true
    override suspend fun execute(command: ParsedCommand)=SkillResult(true, "PC command queued: ${command.raw}")
}
class SmartHomeSkill(private val db: AppDatabase): Skill {
    override val id="smarthome"; override val name="Smart Home"; override val description="ESP32/RPi/MQTT/HTTP"
    override val permissions=listOf()
    override fun canHandle(type: CommandType)=type==CommandType.SMART_HOME
    override fun requiresConfirmation()=true
    override suspend fun execute(command: ParsedCommand)=SkillResult(true, "Smart home: ${command.raw}")
}
