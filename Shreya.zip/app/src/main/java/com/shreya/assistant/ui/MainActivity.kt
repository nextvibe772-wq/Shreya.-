
package com.shreya.assistant.ui
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.shreya.assistant.ui.screens.*
import com.shreya.assistant.ui.theme.ShreyaTheme
import androidx.navigation.compose.*

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ShreyaTheme(darkTheme = true) {
                val nav = rememberNavController()
                NavHost(navController = nav, startDestination = "chat") {
                    composable("chat") { ChatScreen(nav) }
                    composable("api") { ApiSettingsScreen(nav) }
                    composable("settings") { SettingsScreen(nav) }
                    composable("memory") { MemoryScreen(nav) }
                    composable("devices") { DevicesScreen(nav) }
                    composable("developer") { DeveloperConsoleScreen(nav) }
                    composable("diagnostics") { DiagnosticsScreen(nav) }
                    composable("permissions") { PermissionsScreen(nav) }
                }
            }
        }
    }
}
